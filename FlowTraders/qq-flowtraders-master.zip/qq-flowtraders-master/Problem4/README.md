Template file for Flow Traders Quant Quest Problem 4
